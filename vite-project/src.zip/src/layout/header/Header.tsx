
const Header = () => {
  return (
    <header>
      <h1>Users Mangment</h1>
    </header>
  )
}

export default Header
